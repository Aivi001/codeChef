#include<bits/stdc++.h>
using namespace std;

bool Yass(char c)
{
if()
}
int main()
{


}
