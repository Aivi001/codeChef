#include<bits/stdc++.h>
using namespace std;

int main()
{
    /*int j=6;
    int n=1<<3;
    cout<<n<<" ";   //8
    --n;
    cout<<n<<" ";    //7
    n=j^n;
    cout<<n<<" ";       //1        invert bits in a number
    */
    /*int n=3;
    cout<<n<<" ";       //3
    n<<=3;              //(2^3)*n
    cout<<n<<" ";
    //n>>=1;              //n/2
    //cout<<n<<" ";
    n|=1;
    cout<<n<<" ";
      */
     /* int l,r;
      cin>>l>>r;
      int x = l ^ r;
		int max = 0;
        cout<<"x "<<x<<endl;
		while(x > 0)
		{
			max <<= 1;
			max |= 1;
            x >>= 1;
            cout<<max<<" "<<x<<"\n";
		}
        cout<<max<<"\n";

        Maximal xor
        10 15   1010 1111  111=>7

        */

        /*
        Display a number in its binary form
        int n=3;
        cout<<bitset<8>(n)<<" ";  //it is not cout<<bin(n),like python
        */

    return 0;

}
