#include<bits/stdc++.h>
using namespace std;
int main()
{
string s;
cin>>s;
int f=s.find_first_not_of("WUB");
cout<<f;
}
