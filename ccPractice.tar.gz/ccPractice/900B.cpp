#include<iostream>
#include<string>
using namespace std;

int main ()
{
double a,b,c,res;
cin>>a>>b;
res=a/b;
cout<<res<<"\n";

return 0;

}
