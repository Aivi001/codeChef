#include<bits/stdc++.h>
using namespace std;

int main()
{
long long y,k,n,x;
cin>>y>>k>>n;
if(y==n)
{
  cout<<"-1\n";
  return 0;
}
for(int i=k;i<=n;i+=k)
{if()

  /*if((i+y)<=n)
  cout<<i-y<<" ";
  else
  cout<<i;
  */
}
return 0;

}
