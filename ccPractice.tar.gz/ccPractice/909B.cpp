#include<iostream>
#include<algorithm>
using namespace std;

int main()
{
 float a;
 cin>>a;
 cout<<((floor(a/2)+1)*(ceil(a/2)))<<"\n";
 return 0;
}
