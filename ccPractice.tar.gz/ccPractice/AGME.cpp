#include <iostream>
#include<algorithm>
using namespace std;

/*bool binser(int parts[],int noParts,int midVal,int cows)
	{
	/* int last=parts[0];
	 int Imgcows=1;
	 for(int i=0;i<noParts;i++)
	 {
	 	if(parts[i]-last>=midVal)
	 	{
	 		last=parts[i];
	 		++Imgcows;
	 	}
		if(Imgcows==cows)
		 return true;
	 }
	 return false;

	}
	*/
	/*{
		midVal=lo+((hi-lo)/2);
	if(binser(arr,N,midVal,C))
hi=midVal;
else
lo=midVal+1;
	//lo=midVal;
    // else hi=midVal;

	}
	cout<<lo<<"\n";
*/
	// your code here